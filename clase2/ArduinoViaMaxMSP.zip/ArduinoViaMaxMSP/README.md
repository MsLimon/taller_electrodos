Requires OpenSoundControl Max object in Max/MSP folder
